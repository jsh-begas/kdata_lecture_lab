# 패키지 설치
install.packages("corrplot")
install.packages("psych")
install.packages("car")
install.packages("ppcor")

#### 1장 상관분석
library(corrplot)
library(psych)

# fitness 데이터(출처: JMP Software 내 예제 데이터)
setwd('c:/Rproject')
fitness <- read.csv("DAT/Fitness.csv")
head(fitness, 3)
# age: 나이
# weight: 체중
# oxygen: 산소 소비량
# runtime: 1마일을 뛰는데 소요된 시간
# runpulse: 달리는 동안 평균 맥박수
# rstpulse: 휴식기 맥박수
# maxpulse: 달리는 동안 최대 백박수

# Pearson Correlation
cor(fitness[,-(1:2)])

# Spearman Correlation
cor(fitness[,-(1:2)], method="spearman")

# 산점도 행렬 1
pairs.panels(fitness[,-(1:2)], scale=T)

# 상관계수 행렬
M <- cor(fitness[,-(1:2)])
print(round(M, 4))

# 상관계수 행렬 시각화
corrplot(M, method = "circle")
corrplot(M, method = "ellipse", order = "hclust")

# (Question) 최대맥박수가 높으면 소비 산소량도 클까?
# 교재와는 달리 fitness를 계속 이용
pairs.panels(fitness[,c('Oxy','Runtime','MaxPulse')], scale=T)
# 산소 소비량은 달리기 소요 시간과 강한 반비례 (빠를수록 소비량 많음)
# 그냥 상관계수와 이 효과를 보정하는 편 상관계수는 어떻게 다른가?

# 상관계수
round(cor(fitness[,c('Oxy','Runtime','MaxPulse')]),4)
# cor() 함수 사용
# 최대맥박수와 산소소비의 상관계수는 -0.2368

# 편 상관계수
library(ppcor)
round(pcor(fitness[,c('Oxy','Runtime','MaxPulse')])$estimate, 4)
# ppcor package의 pcor() 함수 사용
# 달리기 속도 효과를 보정하고, 최대맥박수와 산소소비의 편 상관계수는 -0.0848

####3장 회귀 분석
## 예제 데이터 
# 유사한 제품을 생산하는 12개 기업에 대해 
# 1년 광고비(독립변수, x)와 매출액(종속변수, y)
x <- c(11, 19, 23, 26, 56, 62, 29, 30, 38, 39, 46, 49)
y <- c(23, 32, 36, 46, 93, 99, 49, 50, 65, 70, 71, 89)

plot(y~x, xlab="adver", ylab="sales")

# 선형회귀모형 적합

# (1) 분산분석표를 작성하고 F-검정을 실시

adsales.lm <- lm(y ~ x)
anova(adsales.lm)

# (2) 결정계수 계산

summary(adsales.lm)

# (3) 광고비(x)의 계수에 관한 검정

summary(adsales.lm)

####4장 잔차 분석
# 표준화 잔차들의 산점도와 정규확률도
par(mfrow=c(2,2))
plot(adsales.lm)
par(mfrow=c(1,1))

# Durbin-Watson 통계량의 적용 예제
library(car)
durbinWatsonTest(adsales.lm)

####5장 이상점과 영향점
# 1년 광고비(독립변수, ad)와 매출액(종속변수, sales) 예제 이어서
infludata<-data.frame(ad=x, sales=y)
infludata.lm<-lm(sales~ad, data=infludata)
summary(infludata.lm)

# 잔차의 절대값이 큰 2개의 자료 (10, 12번) 를 제외
# 10번만 제외하는 경우 
fit.10<-lm(sales~ad, infludata[-10,])
summary(fit.10)
# 12번만 제외하는 경우
fit.12<-lm(sales~ad, infludata[-12,])
summary(fit.12)
# 10, 12번 모두를 제외하는 경우
fit.1012<-lm(sales~ad, infludata[c(-10, -12),])
summary(fit.1012)

# 영향력 측도 분석
par(mfrow=c(1,1))
influence.measures(infludata.lm)



# Cook's Distance
cooks.distance(infludata.lm)
plot(infludata.lm, which=4)

# DFFITS
dffits(infludata.lm)
plot(dffits(infludata.lm), type="h")

# DFBETAS
dfbetas(infludata.lm)
plot(dfbetas(infludata.lm)[,2], type='h') #교재와 다름

####6장 다중공선성
# Boston dataset 
data(Boston)
str(Boston)

# 주택 가격 예측 모형
medv.lm<-lm(medv~., data=Boston)
summary(medv.lm)

# Correlation
Boston.cor<-cor(Boston[1:13])
Boston.cor

# VIF
summary(vif(medv.lm))

# Condition number
eigenval<-eigen(Boston.cor)$values
sqrt(max(eigenval)/min(eigenval))
# 9.820003 출력됨

####7장 변수선택과 모형 선택
# 모형 적합 – 대화식 단계별 선택 방법
# add1() 함수 사용
fit.model0 <- lm(medv ~ 1, data=Boston)
add1(fit.model0, scope = ~ crim + zn + indus + chas + nox + rm + age + dis + rad + tax + ptratio + black + lstat, test = "F")

fit.model1 <-lm(medv ~ crim, data=Boston)
add1(fit.model1, scope = ~ crim + zn + indus + chas + nox + rm + age + dis + rad + tax + ptratio + black + lstat, test = "F")

fit.model2 <- lm(medv ~ crim + zn, data=Boston)
add1(fit.model2, scope = ~ crim + zn + indus + chas + nox + rm + age + dis + rad + tax + ptratio + black + lstat, test = "F")

# 모형 적합 – 단계별회귀(stepwise) 선택 방법
# step() 함수 사용
fit.model <-step(fit.model0, scope = ~ crim + zn + indus + chas + nox + rm + age + dis + rad + tax + ptratio + black + lstat, direction = "both" )
summary(fit.model)

